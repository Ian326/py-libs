"""Constants module for snowflake-connector-python."""

from enum import Enum, unique

from ._internal.authenticator_type import AuthenticatorType  # noqa: F401 - backward compatibility re-exports
from ._internal.type_codes import FIELD_ID_TO_NAME  # noqa: F401 - backward compatibility re-exports
from .config_manager import CONFIG_FILE, CONNECTIONS_FILE  # noqa: F401 - backward compatibility re-exports


@unique
class QueryStatus(Enum):
    RUNNING = 0
    ABORTING = 1
    SUCCESS = 2
    FAILED_WITH_ERROR = 3
    ABORTED = 4
    QUEUED = 5
    FAILED_WITH_INCIDENT = 6
    DISCONNECTED = 7
    RESUMING_WAREHOUSE = 8
    QUEUED_REPARING_WAREHOUSE = 9  # intentional typo, matches server-side QueryDTO.java
    RESTARTED = 10
    BLOCKED = 11
    NO_DATA = 12


# backward compatibility constant
UTF8 = "utf-8"

# Partner programs set this so CLIENT_ENVIRONMENT.APPLICATION is populated
# without passing ``application=`` to connect(). Mirrors snowflake-connector-python.
ENV_VAR_PARTNER = "SF_PARTNER"


class StatementParameterName:
    """Known statement-level parameter names.

    These correspond to the statement-scoped entries in sf_core's
    ``param_registry``.  Pass them via the ``parameters`` dict when
    executing a statement.
    """

    MULTI_STATEMENT_COUNT = "MULTI_STATEMENT_COUNT"
    ASYNC_EXECUTION = "ASYNC_EXECUTION"
    SKIP_UPLOAD_ON_CONTENT_MATCH = "skip_upload_on_content_match"


class SessionParameterName:
    """Known Snowflake session parameter names referenced by the connector."""

    CLIENT_STAGE_ARRAY_BINDING_THRESHOLD = "CLIENT_STAGE_ARRAY_BINDING_THRESHOLD"
    CLIENT_TELEMETRY_ENABLED = "CLIENT_TELEMETRY_ENABLED"
